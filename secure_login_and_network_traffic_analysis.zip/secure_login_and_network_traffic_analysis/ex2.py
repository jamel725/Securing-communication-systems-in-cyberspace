import hashlib
import secrets
import dpkt
users_db = []

def register():
    print("REGISTER:")
    while True:
        username = input("username: ")
        usernameexists = False
        for user in users_db:
            if user['username'] == username:
                usernameexists = True
                break  
        if usernameexists:
            print("Username already exists. Choose another username.")
            continue
        password = input("password: ")
        salt = secrets.token_hex(16)
        hashedpassword = hashingpassword(password, salt)

        newuser = {
            "username": username,
            "salt": salt,
            "password": hashedpassword
        }
        users_db.append(newuser)
        print("You have successfully registered")
        return

def hashingpassword(password, salt):
    salted_password = password + salt
    return hashlib.sha256(salted_password.encode()).hexdigest()

def login():
    print("LOGIN:")
    while True:
        username = input("username: ")
        user = None
        for users in users_db:
            if users['username'] == username:
                user = users
                break

        if user is None:
            print("User not found... try again")
            continue
        else:
            while True:
                password = input("password: ")
                hashedpassword = hashingpassword(password, user['salt'])

                if hashedpassword == user['password']:
                    print("You have successfully connected")
                    return  
                else:
                    print("Wrong password, try again")
                    continue

def main():
    while True:
        print("\n1. Register\n2. Login")
        sign = input("Select option: (1/2) ")

        if sign == "1":
            register()
        elif sign == "2":
            login()
        else:
            print("WRONG INPUT!!!")
            break

def get_ip(pcap_path):
    ip_counts = {}

    with open(pcap_path, 'rb') as f:
        pcap = dpkt.pcap.Reader(f)

        for timestamp, buf in pcap:
            try:
                eth = dpkt.ethernet.Ethernet(buf)
           
                if isinstance(eth.data, dpkt.ip.IP) == True:
                    ip = eth.data
               
                    src_ip = dpkt.utils.inet_to_str(ip.src)
                    dst_ip = dpkt.utils.inet_to_str(ip.dst)

                    if src_ip in ip_counts:
                        ip_counts[src_ip] += 1
                    else:
                        ip_counts[src_ip] = 1

                    if dst_ip in ip_counts:
                        ip_counts[dst_ip] += 1
                    else:
                        ip_counts[dst_ip] = 1
            except Exception as e:
                print(f"Error parsing packet: {e}")
                continue

    return ip_counts


def get_url(pcap_file):
    url_counts = {}
    with open(pcap_file, 'rb') as f:
        pcap = dpkt.pcap.Reader(f)
        for timestamp, buf in pcap:
            try:
                eth = dpkt.ethernet.Ethernet(buf)

                if isinstance(eth.data, dpkt.ip.IP) == True:
                     ip = eth.data
                else:
                    continue
               
                if  isinstance(ip.data, dpkt.tcp.TCP) == True:
                    tcp = ip.data
                else:
                    continue
        
                if tcp.sport == 80 or tcp.dport == 80:  
                    try:
                        http = dpkt.http.Request(tcp.data)
                        host = http.headers.get('host', '')
                        uri = http.uri
                        if host and uri:
                            url = f"http://{host}{uri}"
                            if url in url_counts:
                                url_counts[url] += 1
                            else:
                                url_counts[url] = 1
                    except (dpkt.dpkt.NeedData, dpkt.dpkt.UnpackError):
                        continue
            except Exception as e:
                print(f"Error parsing packet: {e}")
    return url_counts

def get_domain(pcap_path):
    dns_queries = {}

    with open(pcap_path, 'rb') as f:
        pcap = dpkt.pcap.Reader(f)

        for timestamp, buf in pcap:
            try:
              
                eth = dpkt.ethernet.Ethernet(buf)

                if isinstance(eth.data, dpkt.ip.IP) == True:
                     ip = eth.data
                else:
                    continue

                if  isinstance(ip.data, dpkt.udp.UDP) == True:
                     udp = ip.data
                else:
                    continue

                if udp.sport == 53 or udp.dport == 53: 
                    dns = dpkt.dns.DNS(udp.data)

                   
                    if dns.qr == dpkt.dns.DNS_Q:  
                        for query in dns.qd:
                            domain = query.name
                            dns_queries[domain] = dns_queries.get(domain, 0) + 1
            except Exception:
              
                continue

    return dns_queries

pcap_file = r"C:\Users\Jamel\Desktop\2021-11-18-Emotet-infection-with-spambot-activity-carved-and-sanitized.pcap"

print("url:")
url_counts = get_url(pcap_file)
for url ,count in url_counts.items():
    print(f"{url}:{count}")


print("***************************************************************")
print("domains:")
domain_counts = get_domain(pcap_file)
for domain,count in domain_counts.items():
    print(f"{domain}:{count}")

print("***************************************************************")
print("ip:")
ip_counts = get_ip(pcap_file)
for ip,count in ip_counts.items():
    print(f"{ip}:{count}")


print("***************************************************************")
main()